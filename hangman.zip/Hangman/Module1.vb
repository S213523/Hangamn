﻿Module Module1

    Public word As String = "hangman"
    Public guesses As String() = {""}
    Public currGuess As Char()
    Public temp As String

    Sub Main()
        menu()
        drawScreen()
    End Sub

    Sub menu()
        Console.WriteLine("Welcome to my hangman game!")
        Console.Write("Press any key to start...")
        Console.Clear()
    End Sub

    Sub drawScreen()
        Console.Clear()
        For i As Integer = 0 To word.Length() - 1
            For j As Integer = 0 To guesses.Length() - 1
                Debug.WriteLine(j)
                If (word(i) = guesses(j)) Then
                    Console.Write(j)
                Else
                    Console.Write("_")
                End If
            Next
        Next
        Console.WriteLine()
        Console.Write("Please enter your guess: ")
        temp = Console.ReadLine()
        If (Not (temp.Length() = 1)) Then
            Console.WriteLine("Please only enter a single letter!")
            Console.Write("Press any key to continue...")
            drawScreen()
        Else
            currGuess = temp.ToCharArray()
            guess(currGuess(0))
            Console.ReadKey()
        End If
    End Sub

    Function guess(guessChar As Char)
        If (word.Contains(guessChar)) Then
            Console.WriteLine("Yes, it contains " & guessChar)
            Return True
        Else
            Console.WriteLine("No, it dosen't contains " & guessChar)
            Return False
        End If
    End Function

End Module
